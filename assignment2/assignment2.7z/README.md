# Assignment 2: Softmax loss, gradient
You will be asked to modify the following files:
- `softmax.ipynb` (main task)
- `utils/classifiers/softmax.py`
- `utils/classifiers/linear_classifier.py`